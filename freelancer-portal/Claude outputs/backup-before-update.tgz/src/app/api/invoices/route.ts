import { NextResponse } from "next/server";

import connectDB from "@/lib/mongodb";
import Invoice from "@/models/Invoice";
import Payment from "@/models/Payment";
import Client from "@/models/Client";
import Project from "@/models/Project";
import { getAuthenticatedUser } from "@/lib/auth";

export async function GET() {
  try {
    const user = await getAuthenticatedUser();

    if (!user) {
      return NextResponse.json(
        {
          success: false,
          message: "Unauthorized.",
        },
        { status: 401 }
      );
    }

    await connectDB();

    let invoices;

    // ==========================================
    // FREELANCER
    // ==========================================

    if (user.role === "freelancer") {
      invoices = await Invoice.find({
        freelancer: user.id,
      })
        .populate("client", "name company email")
        .populate("project", "name budget")
        .sort({ createdAt: -1 })
        .lean();
    }

    // ==========================================
    // CLIENT
    // ==========================================

    else {
      const linkedClients = await Client.find({
        $or: [
          { user: user.id },
          { email: user.email },
        ],
      }).select("_id");

      const clientIds = linkedClients.map(
        (client) => client._id
      );

      invoices = await Invoice.find({
        client: { $in: clientIds },
      })
        .populate("client", "name company email")
        .populate("project", "name budget")
        .populate("freelancer", "name email")
        .sort({ createdAt: -1 })
        .lean();
    }

    // ==========================================
    // CALCULATE PAID + PENDING FOR EACH INVOICE
    // ==========================================

    const invoicesWithAmounts = await Promise.all(
      invoices.map(async (invoice: any) => {
        const completedPayments =
          await Payment.find({
            invoice: invoice._id,
            status: "Completed",
          }).lean();

        const paidAmount =
          completedPayments.reduce(
            (total, payment) =>
              total + Number(payment.amount || 0),
            0
          );

        /*
         * ======================================
         * MAIN FORMULA
         * ======================================
         *
         * Pending Amount =
         * Invoice/Budget Amount
         * -
         * Completed Payments for THIS Invoice
         */

        const pendingAmount = Math.max(
          Number(invoice.amount || 0) - paidAmount,
          0
        );

        return {
          ...invoice,

          amount: Number(invoice.amount || 0),

          paidAmount,

          pendingAmount,
        };
      })
    );

    return NextResponse.json({
      success: true,
      invoices: invoicesWithAmounts,
    });
  } catch (error) {
    console.error(
      "Get invoices error:",
      error
    );

    return NextResponse.json(
      {
        success: false,
        message: "Failed to fetch invoices.",
      },
      { status: 500 }
    );
  }
}

export async function POST(request: Request) {
  try {
    const user = await getAuthenticatedUser();

    if (!user) {
      return NextResponse.json(
        {
          success: false,
          message: "Unauthorized.",
        },
        { status: 401 }
      );
    }

    if (user.role !== "freelancer") {
      return NextResponse.json(
        {
          success: false,
          message: "Only freelancers can create invoices.",
        },
        { status: 403 }
      );
    }

    await connectDB();

    const body = await request.json();

    const {
      clientId,
      projectId,
      invoiceNumber,
      amount,
      issueDate,
      dueDate,
      status,
    } = body;

    if (
      !clientId ||
      !projectId ||
      !invoiceNumber ||
      amount === undefined ||
      !issueDate ||
      !dueDate
    ) {
      return NextResponse.json(
        {
          success: false,
          message:
            "All required invoice fields must be provided.",
        },
        { status: 400 }
      );
    }

    const invoiceAmount = Number(amount);

    if (
      !Number.isFinite(invoiceAmount) ||
      invoiceAmount <= 0
    ) {
      return NextResponse.json(
        {
          success: false,
          message: "Invoice amount must be greater than 0.",
        },
        { status: 400 }
      );
    }

    // ==========================================
    // VERIFY CLIENT
    // ==========================================

    const client = await Client.findOne({
      _id: clientId,
      freelancer: user.id,
    });

    if (!client) {
      return NextResponse.json(
        {
          success: false,
          message: "Invalid client.",
        },
        { status: 403 }
      );
    }

    // ==========================================
    // VERIFY PROJECT
    // ==========================================

    const project = await Project.findOne({
      _id: projectId,
      freelancer: user.id,
      client: client._id,
    });

    if (!project) {
      return NextResponse.json(
        {
          success: false,
          message: "Invalid project.",
        },
        { status: 403 }
      );
    }

    // ==========================================
    // CHECK DUPLICATE INVOICE NUMBER
    // ==========================================

    const existingInvoice =
      await Invoice.findOne({
        invoiceNumber: invoiceNumber.trim(),
      });

    if (existingInvoice) {
      return NextResponse.json(
        {
          success: false,
          message:
            "Invoice number already exists.",
        },
        { status: 409 }
      );
    }

    // ==========================================
    // CREATE INVOICE
    // ==========================================

    const invoice = await Invoice.create({
      freelancer: user.id,
      client: client._id,
      project: project._id,

      invoiceNumber:
        invoiceNumber.trim(),

      amount: invoiceAmount,

      issueDate,
      dueDate,

      status:
        status || "Pending",
    });

    return NextResponse.json(
      {
        success: true,
        message: "Invoice created successfully.",

        invoice: {
          ...invoice.toObject(),
          paidAmount: 0,
          pendingAmount: invoiceAmount,
        },
      },
      { status: 201 }
    );
  } catch (error) {
    console.error(
      "Create invoice error:",
      error
    );

    return NextResponse.json(
      {
        success: false,
        message: "Failed to create invoice.",
      },
      { status: 500 }
    );
  }
}