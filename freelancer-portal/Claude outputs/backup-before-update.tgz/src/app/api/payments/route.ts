import { NextResponse } from "next/server";

import connectDB from "@/lib/mongodb";
import Payment from "@/models/Payment";
import Invoice from "@/models/Invoice";
import Client from "@/models/Client";
import Project from "@/models/Project";
import { getAuthenticatedUser } from "@/lib/auth";

export async function GET() {
  try {
    const user = await getAuthenticatedUser();

    if (!user) {
      return NextResponse.json(
        {
          success: false,
          message: "Unauthorized.",
        },
        { status: 401 }
      );
    }

    await connectDB();

    let payments;

    // ==========================================
    // FREELANCER PAYMENTS
    // ==========================================

    if (user.role === "freelancer") {
      payments = await Payment.find({
        freelancer: user.id,
      })
        .populate("client", "name company email")
        .populate("project", "name budget")
        .populate(
          "invoice",
          "invoiceNumber amount status"
        )
        .sort({ paymentDate: -1 })
        .lean();
    }

    // ==========================================
    // CLIENT PAYMENTS
    // ==========================================

    else {
      const clientRelationships =
        await Client.find({
          $or: [
            { user: user.id },
            { email: user.email },
          ],
        }).select("_id");

      const clientIds =
        clientRelationships.map(
          (client) => client._id
        );

      payments = await Payment.find({
        client: {
          $in: clientIds,
        },
      })
        .populate(
          "client",
          "name company email"
        )
        .populate(
          "project",
          "name budget"
        )
        .populate(
          "invoice",
          "invoiceNumber amount status"
        )
        .populate(
          "freelancer",
          "name email"
        )
        .sort({ paymentDate: -1 })
        .lean();
    }

    // ==========================================
    // CALCULATE PAYMENT TOTALS PER INVOICE
    // ==========================================

    const invoiceIds = [
      ...new Set(
        payments
          .filter(
            (payment: any) =>
              payment.invoice?._id
          )
          .map(
            (payment: any) =>
              payment.invoice._id.toString()
          )
      ),
    ];

    const allCompletedPayments =
      await Payment.find({
        invoice: {
          $in: invoiceIds,
        },
        status: "Completed",
      })
        .select(
          "invoice amount status"
        )
        .lean();

    const paidByInvoice: Record<
      string,
      number
    > = {};

    for (const payment of allCompletedPayments) {
      const invoiceId =
        payment.invoice.toString();

      if (!paidByInvoice[invoiceId]) {
        paidByInvoice[invoiceId] = 0;
      }

      paidByInvoice[invoiceId] +=
        Number(payment.amount || 0);
    }

    // ==========================================
    // ADD CORRECT CALCULATED VALUES
    // ==========================================

    const paymentsWithCalculations =
      payments.map((payment: any) => {
        const invoiceId =
          payment.invoice?._id?.toString();

        const invoiceAmount =
          Number(
            payment.invoice?.amount || 0
          );

        const paidAmount =
          invoiceId
            ? Number(
                paidByInvoice[
                  invoiceId
                ] || 0
              )
            : 0;

        /*
          CORRECT FORMULA:

          PENDING =
          INVOICE/BUDGET AMOUNT
          -
          COMPLETED PAYMENTS
          FOR THAT SAME INVOICE
        */

        const pendingAmount =
          Math.max(
            invoiceAmount -
              paidAmount,
            0
          );

        return {
          ...payment,

          amount: Number(
            payment.amount || 0
          ),

          invoiceAmount,

          paidAmount,

          pendingAmount,
        };
      });

    return NextResponse.json({
      success: true,
      payments:
        paymentsWithCalculations,
    });
  } catch (error) {
    console.error(
      "Get payments error:",
      error
    );

    return NextResponse.json(
      {
        success: false,
        message:
          "Failed to load payments.",
      },
      { status: 500 }
    );
  }
}


// =====================================================
// CREATE PAYMENT
// =====================================================

export async function POST(
  request: Request
) {
  try {
    const user =
      await getAuthenticatedUser();

    if (!user) {
      return NextResponse.json(
        {
          success: false,
          message: "Unauthorized.",
        },
        { status: 401 }
      );
    }

    await connectDB();

    const body =
      await request.json();

    const {
      invoiceId,
      amount,
      paymentDate,
      paymentMethod,
      status,
    } = body;

    // ==========================================
    // BASIC VALIDATION
    // ==========================================

    if (
      !invoiceId ||
      amount === undefined ||
      !paymentDate ||
      !paymentMethod
    ) {
      return NextResponse.json(
        {
          success: false,
          message:
            "Invoice, amount, payment date and payment method are required.",
        },
        { status: 400 }
      );
    }

    const paymentAmount =
      Number(amount);

    if (
      !Number.isFinite(
        paymentAmount
      ) ||
      paymentAmount <= 0
    ) {
      return NextResponse.json(
        {
          success: false,
          message:
            "Payment amount must be greater than 0.",
        },
        { status: 400 }
      );
    }

    // ==========================================
    // FIND INVOICE
    // ==========================================

    const invoice =
      await Invoice.findById(
        invoiceId
      );

    if (!invoice) {
      return NextResponse.json(
        {
          success: false,
          message: "Invoice not found.",
        },
        { status: 404 }
      );
    }

    // ==========================================
    // VERIFY ACCESS
    // ==========================================

    if (user.role === "freelancer") {
      if (
        invoice.freelancer.toString() !==
        user.id
      ) {
        return NextResponse.json(
          {
            success: false,
            message:
              "You do not have access to this invoice.",
          },
          { status: 403 }
        );
      }
    } else {
      const client =
        await Client.findOne({
          _id: invoice.client,
          $or: [
            { user: user.id },
            { email: user.email },
          ],
        });

      if (!client) {
        return NextResponse.json(
          {
            success: false,
            message:
              "You do not have access to this invoice.",
          },
          { status: 403 }
        );
      }
    }

    // ==========================================
    // VERIFY PROJECT
    // ==========================================

    const project =
      await Project.findOne({
        _id: invoice.project,
        client: invoice.client,
        freelancer:
          invoice.freelancer,
      });

    if (!project) {
      return NextResponse.json(
        {
          success: false,
          message:
            "Invoice project relationship is invalid.",
        },
        { status: 400 }
      );
    }

    // ==========================================
    // GET ALL COMPLETED PAYMENTS
    // FOR THIS SPECIFIC INVOICE
    // ==========================================

    const completedPayments =
      await Payment.find({
        invoice: invoice._id,
        status: "Completed",
      })
        .select("amount")
        .lean();

    const alreadyPaid =
      completedPayments.reduce(
        (total, payment) =>
          total +
          Number(
            payment.amount || 0
          ),
        0
      );

    // ==========================================
    // CORRECT PENDING FORMULA
    // ==========================================

    const invoiceAmount =
      Number(invoice.amount || 0);

    const currentPending =
      Math.max(
        invoiceAmount -
          alreadyPaid,
        0
      );

    // ==========================================
    // PREVENT OVERPAYMENT
    // ==========================================

    if (
      paymentAmount >
      currentPending
    ) {
      return NextResponse.json(
        {
          success: false,
          message: `Payment cannot exceed the pending amount of ₹${currentPending.toLocaleString(
            "en-IN"
          )}.`,
        },
        { status: 400 }
      );
    }

    // ==========================================
    // CREATE PAYMENT
    // ==========================================

    const payment =
      await Payment.create({
        freelancer:
          invoice.freelancer,

        client:
          invoice.client,

        project:
          invoice.project,

        invoice:
          invoice._id,

        amount:
          paymentAmount,

        paymentDate,

        paymentMethod,

        status:
          status || "Completed",
      });

    // ==========================================
    // RECALCULATE AFTER PAYMENT
    // ==========================================

    const allCompletedPaymentsAfter =
      await Payment.find({
        invoice:
          invoice._id,
        status: "Completed",
      })
        .select("amount")
        .lean();

    const totalPaidAfter =
      allCompletedPaymentsAfter.reduce(
        (total, item) =>
          total +
          Number(
            item.amount || 0
          ),
        0
      );

    const pendingAfter =
      Math.max(
        invoiceAmount -
          totalPaidAfter,
        0
      );

    // ==========================================
    // UPDATE INVOICE STATUS
    // ==========================================

    if (pendingAfter === 0) {
      invoice.status = "Paid";
    } else {
      invoice.status = "Pending";
    }

    await invoice.save();

    // ==========================================
    // RETURN PAYMENT
    // ==========================================

    const populatedPayment =
      await Payment.findById(
        payment._id
      )
        .populate(
          "client",
          "name company email"
        )
        .populate(
          "project",
          "name budget"
        )
        .populate(
          "invoice",
          "invoiceNumber amount status"
        )
        .lean();

    return NextResponse.json(
      {
        success: true,

        message:
          "Payment recorded successfully.",

        payment: {
          ...populatedPayment,

          invoiceAmount,

          paidAmount:
            totalPaidAfter,

          pendingAmount:
            pendingAfter,
        },
      },
      { status: 201 }
    );
  } catch (error) {
    console.error(
      "Create payment error:",
      error
    );

    return NextResponse.json(
      {
        success: false,
        message:
          "Failed to record payment.",
      },
      { status: 500 }
    );
  }
}