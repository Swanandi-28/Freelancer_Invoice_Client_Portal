"use client";

import { useCallback, useEffect, useState } from "react";

import ChatThread from "@/components/ChatThread";
import { ErrorBanner, LoadingState, PageHeader } from "@/components/ui";

type Relationship = {
  id: string; // Client relationship id = the conversation
  company: string;
  freelancer: { id?: string; name: string; email: string } | null;
};

type InboxMessage = {
  client?: { _id: string };
  senderRole: "freelancer" | "client";
  read: boolean;
};

export default function ClientMessagesPage() {
  const [relationships, setRelationships] = useState<Relationship[]>([]);
  const [unread, setUnread] = useState<Record<string, number>>({});
  const [selectedId, setSelectedId] = useState("");
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  const loadUnread = useCallback(async () => {
    try {
      const response = await fetch("/api/messages", { cache: "no-store" });
      const data = await response.json();
      if (!response.ok) return;

      const counts: Record<string, number> = {};
      for (const message of (data.messages || []) as InboxMessage[]) {
        if (message.senderRole === "freelancer" && !message.read && message.client?._id) {
          counts[message.client._id] = (counts[message.client._id] || 0) + 1;
        }
      }
      setUnread(counts);
    } catch {
      // Unread badges are optional; ignore network errors here.
    }
  }, []);

  const loadRelationships = useCallback(async () => {
    try {
      setLoading(true);
      setError("");

      // Each freelancer relationship is its own private conversation.
      const response = await fetch("/api/dashboard/client", { cache: "no-store" });
      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.message || "Failed to load conversations.");
      }

      const list: Relationship[] = data.freelancers || [];
      setRelationships(list);

      const requested = new URLSearchParams(window.location.search).get("conversation");
      setSelectedId(
        (current) =>
          current ||
          list.find((item) => item.id === requested)?.id ||
          list[0]?.id ||
          ""
      );

      await loadUnread();
    } catch (reason) {
      setError(
        reason instanceof Error ? reason.message : "Failed to load conversations."
      );
    } finally {
      setLoading(false);
    }
  }, [loadUnread]);

  useEffect(() => {
    loadRelationships();
  }, [loadRelationships]);

  const selected = relationships.find((item) => item.id === selectedId);

  const openConversation = (id: string) => {
    setSelectedId(id);
    setUnread((current) => ({ ...current, [id]: 0 }));
  };

  return (
    <div className="p-4 md:p-8">
      <PageHeader
        title="Messages"
        subtitle="Private conversations with each of your freelancers."
      />

      <ErrorBanner message={error} onRetry={loadRelationships} />

      {loading ? (
        <LoadingState label="Loading conversations..." />
      ) : relationships.length === 0 ? (
        <div className="rounded-2xl border border-white/10 bg-[#111827] p-10 text-center text-gray-400">
          No conversations yet. Once a freelancer adds you as a client, you can
          message them here.
        </div>
      ) : (
        <div className="grid overflow-hidden rounded-2xl border border-white/10 bg-[#111827] md:grid-cols-[280px_1fr]">
          {/* CONVERSATION LIST */}
          <div className="border-b border-white/10 md:border-b-0 md:border-r">
            {relationships.map((relationship) => (
              <button
                key={relationship.id}
                onClick={() => openConversation(relationship.id)}
                className={`flex w-full items-center justify-between gap-3 border-b border-white/5 px-5 py-4 text-left transition last:border-0 ${
                  relationship.id === selectedId ? "bg-blue-600/15" : "hover:bg-white/5"
                }`}
              >
                <div className="min-w-0">
                  <p className="truncate font-medium">
                    {relationship.freelancer?.name || "Freelancer"}
                  </p>
                  <p className="truncate text-xs text-gray-500">
                    {relationship.company}
                  </p>
                </div>
                {unread[relationship.id] > 0 && relationship.id !== selectedId && (
                  <span className="rounded-full bg-blue-600 px-2 py-0.5 text-xs font-medium">
                    {unread[relationship.id]}
                  </span>
                )}
              </button>
            ))}
          </div>

          {/* CHAT */}
          <div className="min-w-0">
            {selected && (
              <>
                <div className="border-b border-white/10 px-5 py-4">
                  <p className="font-semibold">
                    {selected.freelancer?.name || "Freelancer"}
                  </p>
                  <p className="text-xs text-gray-500">
                    {selected.freelancer?.email} · {selected.company}
                  </p>
                </div>
                <ChatThread
                  key={selected.id}
                  clientId={selected.id}
                  viewerRole="client"
                />
              </>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
