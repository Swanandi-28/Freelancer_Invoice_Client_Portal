"use client";

import { useCallback, useEffect, useRef, useState } from "react";

import { formatDateTime, inputClass } from "@/components/ui";

type ChatMessage = {
  _id: string;
  senderRole: "freelancer" | "client";
  message: string;
  createdAt: string;
  project?: { _id: string; name: string } | null;
};

/*
  One private conversation = one freelancer-client relationship
  (clientId is the Client relationship id). The server checks that
  the logged-in user belongs to that relationship on every request.
*/
export default function ChatThread({
  clientId,
  viewerRole,
  onActivity,
}: {
  clientId: string;
  viewerRole: "freelancer" | "client";
  onActivity?: () => void;
}) {
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [text, setText] = useState("");
  const [loading, setLoading] = useState(true);
  const [sending, setSending] = useState(false);
  const [error, setError] = useState("");

  const bottomRef = useRef<HTMLDivElement>(null);

  const loadMessages = useCallback(
    async (silent = false) => {
      try {
        if (!silent) setLoading(true);

        const response = await fetch(
          `/api/messages?clientId=${encodeURIComponent(clientId)}`,
          { cache: "no-store" }
        );
        const data = await response.json();

        if (!response.ok) {
          throw new Error(data.message || "Failed to load messages.");
        }

        setMessages(data.messages || []);
        setError("");
      } catch (reason) {
        if (!silent) {
          setError(
            reason instanceof Error ? reason.message : "Failed to load messages."
          );
        }
      } finally {
        if (!silent) setLoading(false);
      }
    },
    [clientId]
  );

  useEffect(() => {
    setMessages([]);
    loadMessages();

    // Lightweight refresh so replies appear without a manual reload.
    const timer = setInterval(() => loadMessages(true), 15000);
    return () => clearInterval(timer);
  }, [loadMessages]);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ block: "nearest" });
  }, [messages.length]);

  const sendMessage = async (event: React.FormEvent) => {
    event.preventDefault();

    const trimmed = text.trim();
    if (!trimmed || sending) return;

    try {
      setSending(true);
      setError("");

      const response = await fetch("/api/messages", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ clientId, message: trimmed }),
      });
      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.message || "Failed to send message.");
      }

      setText("");
      await loadMessages(true);
      onActivity?.();
    } catch (reason) {
      setError(
        reason instanceof Error ? reason.message : "Failed to send message."
      );
    } finally {
      setSending(false);
    }
  };

  return (
    <div className="flex h-full min-h-[420px] flex-col">
      <div className="max-h-[480px] flex-1 space-y-3 overflow-y-auto p-5">
        {loading ? (
          <p className="py-10 text-center text-sm text-gray-500">
            Loading messages...
          </p>
        ) : messages.length === 0 ? (
          <p className="py-10 text-center text-sm text-gray-500">
            No messages yet. Start the conversation.
          </p>
        ) : (
          messages.map((message) => {
            const mine = message.senderRole === viewerRole;

            return (
              <div
                key={message._id}
                className={`flex ${mine ? "justify-end" : "justify-start"}`}
              >
                <div
                  className={`max-w-[80%] rounded-2xl px-4 py-3 text-sm ${
                    mine
                      ? "bg-blue-600 text-white"
                      : "border border-white/10 bg-white/5 text-gray-200"
                  }`}
                >
                  {message.project?.name && (
                    <p className="mb-1 text-xs opacity-70">
                      Re: {message.project.name}
                    </p>
                  )}
                  <p className="whitespace-pre-wrap break-words">
                    {message.message}
                  </p>
                  <p className="mt-1 text-right text-[11px] opacity-60">
                    {formatDateTime(message.createdAt)}
                  </p>
                </div>
              </div>
            );
          })
        )}
        <div ref={bottomRef} />
      </div>

      {error && (
        <p role="alert" className="px-5 pb-2 text-sm text-red-400">
          {error}
        </p>
      )}

      <form
        onSubmit={sendMessage}
        className="flex gap-3 border-t border-white/10 p-4"
      >
        <input
          value={text}
          onChange={(event) => setText(event.target.value)}
          placeholder="Type a message..."
          maxLength={5000}
          className={inputClass}
        />
        <button
          type="submit"
          disabled={sending || !text.trim()}
          className="rounded-lg bg-blue-600 px-5 py-3 text-sm font-medium transition hover:bg-blue-500 disabled:cursor-not-allowed disabled:opacity-50"
        >
          {sending ? "Sending..." : "Send"}
        </button>
      </form>
    </div>
  );
}
